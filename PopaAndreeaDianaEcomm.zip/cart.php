<?php
include("con la DB.php");

?>

<!DOCTYPE html>
<html>
	<head>
		<title>La Boutique</title>
		<link rel="stylesheet" href="style.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	</head>
	<body>

<div class="container"> 
		<div class="navbar">
	<div class = "logo">
		<img src="pics/LOGO2.png" width="30%" alt="" style="padding-top: 5px; padding-left: 5px;">
 </div>
 <nav>
 	<ul>
 		<li><a href="index.php">Products</a></li><img src="pics/home.png" style="padding-right: 10px;" width="50px" height="50px">
 		<li><a href="cart.php">Cart</a></li><img src="pics/cart.png" width="50px" height="50px">
 	</ul>
 </nav>
 
  </div>
		<br />
		<div class="container">
			<br />
			<br />
			<br />
			<h3 align="center">La Boutique Online Store</a></h3><br />
			<br /><br />


<?php

$result = mysqli_query($connect,"SELECT * FROM cart");

echo "<div>";
echo "<table class='table table-hover'>";
echo "<thead>
<tr>
<th scope='col'>No</th>
<th scope='col'>ID</th>
<th scope='col'>Quantity</th>
<th scope='col'>Product</th>
<th scope='col'>Price</th>
</tr>
</thead>";

$count = 1;
$total = 0;
while($row = mysqli_fetch_array($result))
{
echo "<tbody>";
$idprod = $row['idprod'];
echo "<tr>";
echo "<td>" . $count . "</td>";
echo "<td>" . $row['idprod'] . "</td>";
echo "<td>" . $row['cantitate'] . "</td>";
echo "<td>" . $row['numeprod'] . "</td>";
echo "<td>" . $row['pret'] . "</td>";
$total = $total + ($row['pret']*$row['cantitate']);
echo "</tr>";
$count++;
}
echo "</tbody>";
echo "</table>";
echo "<h2>Total: ".$total."</h2>";
echo "</div>";
?>
<div style="margin-top: 20px;
    margin-left: auto;
    margin-right: auto;
    width: 18em;">
    <form action="cantitate.php" method="GET" id="form1">
	<input type="text" name="cantitate" placeholder="ID product to be edited">
	<br />
	<div style="margin-top: 10px !important;">
	<button type="submit" name="submit1" class="btn btn-primary">Edit Selected!</button>
	</form>
</div>

<div style="margin-top: 20px;
    margin-left: auto;
    margin-right: auto;
    width: 18em;">
    <form action="remove.php" method="POST" id="form2">
	<input type="text" name="stergere" placeholder="ID product to be removed">
	<br />
	<div style="margin-top: 10px !important;">
	<button type="submit" name="submit" class="btn btn-primary">Remove Selected!</button>
	</form>
</div>

