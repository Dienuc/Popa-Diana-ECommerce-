<?php
$var_value = $_GET['cantitate'];

echo "ID: " . $var_value . "<br>";

include("con la DB.php");

$sql = "SELECT * FROM cart where idprod = '$var_value'";

$result = mysqli_query($connect, $sql);

if ($result->num_rows > 0){

$row = $result->fetch_assoc();

$nume = $row["numeprod"];
$pret = $row["pret"];
$cantitate = $row["cantitate"];
echo "Product: ".$nume. "<br>";
echo "Price: ".$pret. "<br>";
echo "Former Quantity: ".$cantitate. "<br>";
}

?>
<form action="cantitatescript.php" method="POST">
  <input type="hidden" name="id" value=" <?php echo $var_value; ?> ">
  <input type="text" name="cant" placeholder="Enter Quantity">
  <br />
  <div style="margin-top: 10px !important;">
  <button type="submit" name="submit" class="btn btn-primary">Submit!</button>

