<?php

$connect = mysqli_connect("localhost", "root", "","dbdianaecom");
if(mysqli_connect_errno())
{
	echo "Eroare de conexiune la BD" .mysqli_connect_error();
	exit;
}


?>