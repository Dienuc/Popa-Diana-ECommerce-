<?php
$var_value = $_POST['stergere'];

include("con la DB.php");
include("redirectionare.php");

$sql = "DELETE FROM cart WHERE idprod = '$var_value'";

if ($connect->query($sql) === TRUE) {
  echo "Produs Sters";
} else {
  echo "Error: ".$sql."<br>".$connect->error;
}

$connect->close();

redirectionare('cart.php');

?>