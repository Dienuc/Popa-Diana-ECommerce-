<?php

$id = $_POST['id'];
$cant = $_POST['cant'];

echo $cant;
echo $id;

include("con la DB.php");
include("redirectionare.php");

$sql = "update cart set cantitate='$cant' where idprod='$id'"; //UPDATE

if ($connect->query($sql) === TRUE) {
  echo "Q modified!";
} else {
  echo "Error: ".$sql."<br>".$link->error;
}

$connect->close();

redirectionare('cart.php');

?>